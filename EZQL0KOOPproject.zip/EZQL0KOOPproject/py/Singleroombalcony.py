from Rooms import Room


class Singleroombalcony(Room):
    def __init__(self, number, price):
        super().__init__(number, price)
        self.extras.extend(["single bed", "balcony", "sofa"])