from Doubleroombalcony import Doubleroombalcony
from Doubleroom import DoubleRoom
from Singleroombalcony import Singleroombalcony
from Singleroom import SingleRoom
from Hotel import Levhotel
from User import User



user1 = User(1, "Teszt felhasználó", "teszt@gmail.com", "1234 Budapest Teszt utca 1", "asd123")

class BookingSystem:
    def __init__(self):
        self.hotel = Levhotel()

    def load_data(self):
        self.hotel.add_room(SingleRoom(21, 50))
        self.hotel.add_room(DoubleRoom(22, 75))
        self.hotel.add_room(Singleroombalcony(201, 120))
        self.hotel.add_room(Doubleroombalcony(201, 120))

    def interact1(self):
        available = self.hotel.check_availability()
        return available
    def interact2(self):
        not_available = self.hotel.check_booked()
        return not_available

    def interact3(self):
        from Booking import getit
        self.hotel.book_room_by_number(getit)
    def interact4(self):
        from Cancellbooked import getit
        self.hotel.unbook_room_by_number(getit)



# Example usage
booking_system = BookingSystem()

booking_system.load_data()



