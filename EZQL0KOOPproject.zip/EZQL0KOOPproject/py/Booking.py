from tkinter import *
import subprocess
import sys
import os


'''Ablak letrehozasa'''

root4 = Tk()
root4.overrideredirect(True)
app_width = 800
app_height =500
root4.geometry(f'{app_width}x{app_height}')

'''Ablak letrehozasa'''

'''Tegyük középre'''
def kozep(win):
    win.update_idletasks()
    width = win.winfo_width()
    frm_width = win.winfo_rootx() - win.winfo_x()
    win_width = width + 2 * frm_width
    height = win.winfo_height()
    titlebar_height = win.winfo_rooty() - win.winfo_y()
    win_height = height + titlebar_height + frm_width
    x = win.winfo_screenwidth() // 2 - win_width // 2
    y = win.winfo_screenheight() // 2 - win_height // 2
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))
    win.deiconify()

kozep(root4)

'''Tegyük középre'''

'''Csináljuk mozgathatóvá'''
lastClickX = 0
lastClickY = 0

def utsopozi(event):
    global lastClickX, lastClickY
    lastClickX = event.x
    lastClickY = event.y

def mozgat(event):
    x, y = event.x - lastClickX + root4.winfo_x(), event.y - lastClickY + root4.winfo_y()
    root4.geometry("+%s+%s" % (x , y))

root4.attributes('-topmost', True)
root4.bind('<Button-1>', utsopozi)
root4.bind('<B1-Motion>', mozgat)

'''Csináljuk mozgathatóvá'''

'''Felület létrehozása, kilépés gomb'''

def exit(event):
    root4.quit()


def cucc(event):
    try:
        # Próbáljuk meg elindítani a második programot
        subprocess.Popen([sys.executable, os.path.join(os.getcwd(), "Lilwin.py")])
        # Bezárjuk az első programot

    except Exception as e:
        # Hibakezelés: nyomtatjuk a hibaüzenetet
        print(f"Hiba történt a második program indításakor: {e}")
        getit = e1.get()


def cancell(event):
    try:
        # Próbáljuk meg elindítani a második programot
        subprocess.Popen([sys.executable, os.path.join(os.getcwd(), "Cancellbooked.py")])
        # Bezárjuk az első programot
        root4.after(2000, root4.destroy)
    except Exception as e:
        # Hibakezelés: nyomtatjuk a hibaüzenetet
        print(f"Hiba történt a második program indításakor: {e}")

def available(event):
    try:
        # Próbáljuk meg elindítani a második programot
        subprocess.Popen([sys.executable, os.path.join(os.getcwd(), "Available.py")])
        # Bezárjuk az első programot
        root4.after(2000, root4.destroy)
    except Exception as e:
        # Hibakezelés: nyomtatjuk a hibaüzenetet
        print(f"Hiba történt a második program indításakor: {e}")

canvas = Canvas(root4, width=800, height=36)
canvas.config(bg="#033852")
canvas.pack()

kilep = canvas.create_text(750, 18, text="Kilépés", fill="white", font=('Verdana 10 underline'), tags='kilepp')
canvas.pack()
canvas.tag_bind('kilepp', "<Button-1>", exit)

felirat = canvas.create_text(100, 18, text="Zsidai Levente", fill="white", font=('Verdana 14'))
canvas.pack()

canvas = Canvas(root4, width=800, height=464)
canvas.config(bg="#044A6B")
canvas.pack()

topl = LabelFrame(root4, text="", bg='#044A6B')
topl.place(x=2,y=41, width=398, height=60)
title = Label(topl,text="Szabad szobák", fg="white", font=('Verdana 18'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: available(event))

topr = LabelFrame(root4, text="", bg='#044A6B')
topr.place(x=400,y=41, width=398, height=60)
title = Label(topr,text="Foglalás lemondása", fg="white", font=('Verdana 18'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: cancell(event))

f2 = LabelFrame(root4, text="", bg='#044A6B')
f2.place(x=3,y=350, width=500, height=50)
l2 = Label(f2,text="Foglalás szobaszám alapján:", fg="white", font=('Verdana 15'),bg='#044A6B')
l2.place(x=180,y=23, anchor="center")

f3 = LabelFrame(root4, text="", bg='#005F73')
f3.place(x=354,y=350, width=50, height=50)
e1 = Entry(f3,fg="white", font=('Verdana 15 underline'),bg='#005F73')
e1.place(width=50, height=50)
getit = e1.get()

f4 = LabelFrame(root4, text="", bg='#005F73')
f4.place(x=405,y=350, width=100, height=50)
l3 = Label(f4,text="Foglalás", fg="white", font=('Verdana 15 underline'),bg='#005F73')
l3.place(x=50, y=23, anchor="center")
l3.bind("<ButtonPress-1>",lambda event: cucc(event))


l4 = Label(root4,text="", fg="red", font=('Verdana 15'),bg='#044A6B')
l4.place(x=50, y=430, anchor="center")



'''Felület létrehozása, kilépés gomb'''





'''És hogy a képernyőn is maradjon'''

root4.mainloop()

'''És hogy a képernyőn is maradjon'''