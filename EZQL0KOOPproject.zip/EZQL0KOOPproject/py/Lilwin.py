from tkinter import *
from main import booking_system
import subprocess
import sys
import os




'''Ablak letrehozasa'''

root5 = Tk()
root5.overrideredirect(True)
app_width = 800
app_height =500
root5.geometry(f'{app_width}x{app_height}')

'''Ablak letrehozasa'''

'''Tegyük középre'''
def kozep(win):
    win.update_idletasks()
    width = win.winfo_width()
    frm_width = win.winfo_rootx() - win.winfo_x()
    win_width = width + 2 * frm_width
    height = win.winfo_height()
    titlebar_height = win.winfo_rooty() - win.winfo_y()
    win_height = height + titlebar_height + frm_width
    x = win.winfo_screenwidth() // 2 - win_width // 2
    y = win.winfo_screenheight() // 2 - win_height // 2
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))
    win.deiconify()

kozep(root5)

'''Tegyük középre'''

'''Csináljuk mozgathatóvá'''
lastClickX = 0
lastClickY = 0

def utsopozi(event):
    global lastClickX, lastClickY
    lastClickX = event.x
    lastClickY = event.y

def mozgat(event):
    x, y = event.x - lastClickX + root5.winfo_x(), event.y - lastClickY + root5.winfo_y()
    root5.geometry("+%s+%s" % (x , y))

root5.attributes('-topmost', True)
root5.bind('<Button-1>', utsopozi)
root5.bind('<B1-Motion>', mozgat)

'''Csináljuk mozgathatóvá'''

'''Felület létrehozása, kilépés gomb'''

def exit(event):
    root5.quit()

def progress(event):
    booking_system.interact3()
    from Booking import e1
    e1.delete(0, END)
    root5.quit()


canvas = Canvas(root5, width=800, height=36)
canvas.config(bg="#033852")
canvas.pack()

kilep = canvas.create_text(750, 18, text="Kilépés", fill="white", font=('Verdana 10 underline'), tags='kilepp')
canvas.pack()
canvas.tag_bind('kilepp', "<Button-1>", exit)

felirat = canvas.create_text(100, 18, text="Zsidai Levente", fill="white", font=('Verdana 14'))
canvas.pack()

canvas = Canvas(root5, width=800, height=464)
canvas.config(bg="#044A6B")
canvas.pack()

title = Label(root5,text="Biztos lefoglalod?", fg="white", font=('Verdana 18'),bg='#044A6B')
title.place(x=120, y=70, anchor="center")


topl = LabelFrame(root5, text="", bg='#044A6B')
topl.place(x=2,y=100, width=398, height=60)
title = Label(topl,text="Igen", fg="white", font=('Verdana 18 underline'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: progress(event))

topr = LabelFrame(root5, text="", bg='#044A6B')
topr.place(x=400,y=100, width=398, height=60)
title = Label(topr,text="Nem", fg="white", font=('Verdana 18 underline'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: exit(event))




'''Felület létrehozása, kilépés gomb'''





'''És hogy a képernyőn is maradjon'''

root5.mainloop()

'''És hogy a képernyőn is maradjon'''