from Rooms import Room


class Doubleroombalcony(Room):
    def __init__(self, number, price):
        super().__init__(number, price)
        self.extras.extend(["double bed", "balcony", "sofa"])