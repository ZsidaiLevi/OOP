from tkinter import *
from main import booking_system
import subprocess
import sys
import os




'''Ablak letrehozasa'''

root6 = Tk()
root6.overrideredirect(True)
app_width = 800
app_height =500
root6.geometry(f'{app_width}x{app_height}')

'''Ablak letrehozasa'''

'''Tegyük középre'''
def kozep(win):
    win.update_idletasks()
    width = win.winfo_width()
    frm_width = win.winfo_rootx() - win.winfo_x()
    win_width = width + 2 * frm_width
    height = win.winfo_height()
    titlebar_height = win.winfo_rooty() - win.winfo_y()
    win_height = height + titlebar_height + frm_width
    x = win.winfo_screenwidth() // 2 - win_width // 2
    y = win.winfo_screenheight() // 2 - win_height // 2
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))
    win.deiconify()

kozep(root6)

'''Tegyük középre'''

'''Csináljuk mozgathatóvá'''
lastClickX = 0
lastClickY = 0

def utsopozi(event):
    global lastClickX, lastClickY
    lastClickX = event.x
    lastClickY = event.y

def mozgat(event):
    x, y = event.x - lastClickX + root6.winfo_x(), event.y - lastClickY + root6.winfo_y()
    root6.geometry("+%s+%s" % (x , y))

root6.attributes('-topmost', True)
root6.bind('<Button-1>', utsopozi)
root6.bind('<B1-Motion>', mozgat)

'''Csináljuk mozgathatóvá'''

'''Felület létrehozása, kilépés gomb'''

def exit(event):
    root6.quit()

def progress(event):
    booking_system.interact4()
    from Cancellbooked import e1
    e1.delete(0, END)
    root6.quit()


canvas = Canvas(root6, width=800, height=36)
canvas.config(bg="#033852")
canvas.pack()

kilep = canvas.create_text(750, 18, text="Kilépés", fill="white", font=('Verdana 10 underline'), tags='kilepp')
canvas.pack()
canvas.tag_bind('kilepp', "<Button-1>", exit)

felirat = canvas.create_text(100, 18, text="Zsidai Levente", fill="white", font=('Verdana 14'))
canvas.pack()

canvas = Canvas(root6, width=800, height=464)
canvas.config(bg="#044A6B")
canvas.pack()

title = Label(root6,text="Biztos lemondod?", fg="white", font=('Verdana 18'),bg='#044A6B')
title.place(x=120, y=70, anchor="center")


topl = LabelFrame(root6, text="", bg='#044A6B')
topl.place(x=2,y=100, width=398, height=60)
title = Label(topl,text="Igen", fg="white", font=('Verdana 18 underline'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: progress(event))

topr = LabelFrame(root6, text="", bg='#044A6B')
topr.place(x=400,y=100, width=398, height=60)
title = Label(topr,text="Nem", fg="white", font=('Verdana 18 underline'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: exit(event))




'''Felület létrehozása, kilépés gomb'''





'''És hogy a képernyőn is maradjon'''

root6.mainloop()

'''És hogy a képernyőn is maradjon'''