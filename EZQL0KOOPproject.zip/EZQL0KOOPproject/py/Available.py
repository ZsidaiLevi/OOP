from tkinter import *
from main import booking_system
import subprocess
import sys
import os




'''Ablak letrehozasa'''

root2 = Tk()
root2.overrideredirect(True)
app_width = 800
app_height =500
root2.geometry(f'{app_width}x{app_height}')

'''Ablak letrehozasa'''

'''Tegyük középre'''
def kozep(win):
    win.update_idletasks()
    width = win.winfo_width()
    frm_width = win.winfo_rootx() - win.winfo_x()
    win_width = width + 2 * frm_width
    height = win.winfo_height()
    titlebar_height = win.winfo_rooty() - win.winfo_y()
    win_height = height + titlebar_height + frm_width
    x = win.winfo_screenwidth() // 2 - win_width // 2
    y = win.winfo_screenheight() // 2 - win_height // 2
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))
    win.deiconify()

kozep(root2)

'''Tegyük középre'''

'''Csináljuk mozgathatóvá'''
lastClickX = 0
lastClickY = 0

def utsopozi(event):
    global lastClickX, lastClickY
    lastClickX = event.x
    lastClickY = event.y

def mozgat(event):
    x, y = event.x - lastClickX + root2.winfo_x(), event.y - lastClickY + root2.winfo_y()
    root2.geometry("+%s+%s" % (x , y))

root2.attributes('-topmost', True)
root2.bind('<Button-1>', utsopozi)
root2.bind('<B1-Motion>', mozgat)

'''Csináljuk mozgathatóvá'''

'''Felület létrehozása, kilépés gomb'''

def exit(event):
    root2.quit()



def cancell(event):
    try:
        # Próbáljuk meg elindítani a második programot
        subprocess.Popen([sys.executable, os.path.join(os.getcwd(), "Cancellbooked.py")])
        # Bezárjuk az első programot
        root2.after(2000, root2.destroy)
    except Exception as e:
        # Hibakezelés: nyomtatjuk a hibaüzenetet
        print(f"Hiba történt a második program indításakor: {e}")


def bookingwin(event):
    try:
        # Próbáljuk meg elindítani a második programot
        subprocess.Popen([sys.executable, os.path.join(os.getcwd(), "Booking.py")])
        # Bezárjuk az első programot
        root2.after(2000, root2.destroy)
    except Exception as e:
        # Hibakezelés: nyomtatjuk a hibaüzenetet
        print(f"Hiba történt a második program indításakor: {e}")


canvas = Canvas(root2, width=800, height=36)
canvas.config(bg="#033852")
canvas.pack()

kilep = canvas.create_text(750, 18, text="Kilépés", fill="white", font=('Verdana 10 underline'), tags='kilepp')
canvas.pack()
canvas.tag_bind('kilepp', "<Button-1>", exit)

felirat = canvas.create_text(100, 18, text="Zsidai Levente", fill="white", font=('Verdana 14'))
canvas.pack()

canvas = Canvas(root2, width=800, height=464)
canvas.config(bg="#044A6B")
canvas.pack()

topl = LabelFrame(root2, text="", bg='#044A6B')
topl.place(x=2,y=41, width=398, height=60)
title = Label(topl,text="Áttekintés", fg="white", font=('Verdana 18 underline'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")


topr = LabelFrame(root2, text="", bg='#044A6B')
topr.place(x=400,y=41, width=398, height=60)
title = Label(topr,text="Foglalás lemondása", fg="white", font=('Verdana 18 underline'),bg='#044A6B')
title.place(x=199, y=30, anchor="center")
title.bind("<ButtonPress-1>",lambda event: cancell(event))

title = Label(root2,text="Szabad szobák:", fg="white", font=('Verdana 18'),bg='#044A6B')
title.place(x=120, y=140, anchor="center")

f1 = LabelFrame(root2, text="", bg='#005F73')
f1.place(x=3,y=160, width=794, height=50)
l1 = Label(f1,text=booking_system.interact1(), fg="white", font=('Verdana 15'),bg='#005F73')
l1.place(x=130, y=23, anchor="center")

title = Label(root2,text="Foglalt szobák:", fg="white", font=('Verdana 18'),bg='#044A6B')
title.place(x=120, y=250, anchor="center")

f2 = LabelFrame(root2, text="", bg='#005F73')
f2.place(x=3,y=270, width=794, height=50)
l2 = Label(f2,text=booking_system.interact2(), fg="white", font=('Verdana 15 underline'),bg='#005F73')
l2.place(x=130, y=23, anchor="center")

f4 = LabelFrame(root2, text="", bg='#005F73')
f4.place(x=405,y=350, width=100, height=50)
l3 = Label(f4,text="Foglalás", fg="white", font=('Verdana 15 underline'),bg='#005F73')
l3.place(x=50, y=23, anchor="center")
l3.bind("<ButtonPress-1>",lambda event: bookingwin(event))


l4 = Label(root2,text="", fg="red", font=('Verdana 15'),bg='#044A6B')
l4.place(x=50, y=430, anchor="center")



'''Felület létrehozása, kilépés gomb'''





'''És hogy a képernyőn is maradjon'''

root2.mainloop()

'''És hogy a képernyőn is maradjon'''