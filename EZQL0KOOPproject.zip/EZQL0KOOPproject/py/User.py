class User:
    def __init__(self, id, name, email, address, passw):
        self.id = id
        self.name = name
        self.email = email
        self.address = address
        self.passw = passw